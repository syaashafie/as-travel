# AS Travel ✈️👨‍👩‍👧
Mobile-first family travel PWA.

Files:
- index.html
- manifest.webmanifest
- sw.js

To install on iPhone after hosting:
Safari → open the site → Share → Add to Home Screen.
